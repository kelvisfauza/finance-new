# Great Pearl Finance — React + Supabase

Minimal finance app: payments, expenses, approvals, pricing, statements, reports.

## Setup
1) Run SQL in `supabase.sql` in your Supabase project.
2) Copy `.env.example` to `.env.local` and fill:
```
VITE_SUPABASE_URL=...
VITE_SUPABASE_ANON_KEY=...
```
3) Install & run:
```
npm install
npm run dev
```

## Build
```
npm run build
npm run preview
```
